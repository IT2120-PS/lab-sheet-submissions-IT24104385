getwd()
branch.data <- read.table("Exercise.txt", header = TRUE, sep = ",")
fix(branch.data)

attach(branch.data)
attach(branch.data)

#check the data
head(branch.data)

#view the structure of the data
str(branch.data)


#Branch → Nominal (categorical)
#Sales_X1 → Ratio (continuous numeric)
#Advertising_X2 → Ratio (continuous numeric)
#Years_X3 → Ratio (discrete numeric)

#Boxplot for sales
boxplot(branch.data$Sales_X1, main="Boxplot of sales", xlab="Branch", ylab="Sales",outpch = 8)

#Get five number summary for advertising_X2
summary(Advertising_X2)
quantile(Advertising_X2)

#Getting IQR for advertising_X2
IQR(Advertising_X2)

#function to chech outliers in dataset
get.outliers<- function(z){
  Q1 <- quantile(z, 0.25)
  Q3 <- quantile(z, 0.75)
  Iqr_value <- Q3 - Q1
  
  Upper_bound <- Q3 +1.5*Iqr_value
  Lower_bound <- Q1-1.5*Iqr_value
  
  outliers <- z[z < Lower_bound | z > Upper_bound]
  return(outliers)
}


#Check for outliers in Years
get.outliers(branch.data$Years_X3)



