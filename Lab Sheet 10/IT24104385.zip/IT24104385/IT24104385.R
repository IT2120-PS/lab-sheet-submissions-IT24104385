setwd ("C:\\Users\\Senuka\\Desktop\\Y2S1\\PS\\Lab\\Lab10\\IT24104385")

# ============================================================
# IT2120 - Probability and Statistics
# Lab 10 - Exercise 1
# Chi-Square Goodness-of-Fit Test
# ============================================================

# Observed frequencies for snack types A, B, C, D
snacks <- c(120, 95, 85, 100)

# Label the categories
names(snacks) <- c("A", "B", "C", "D")

# Expected probabilities under H0 (equal choice)
p_equal <- rep(1/4, 4)

# Perform the Chi-square goodness-of-fit test
chisq_result <- chisq.test(snacks, p = p_equal)

# Display the results
print(chisq_result)

# Optional: Extract and display key values neatly
cat("\nChi-square statistic:", chisq_result$statistic)
cat("\nDegrees of freedom:", chisq_result$parameter)
cat("\nP-value:", chisq_result$p.value)
cat("\nConclusion: If p-value < 0.05, reject H0 (not equally chosen).\n")
